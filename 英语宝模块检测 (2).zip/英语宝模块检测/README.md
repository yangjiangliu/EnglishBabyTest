# 英语宝模块检测 · C 同学（错误溯源 & 输出交付）

本项目是「英语宝模块检测智能体」三人协作中 **C 同学** 负责的最后一环：
**错误溯源 + 报告输出 + 分发**。代码严格按《给C的分工文档》编写。

## 目录结构

```
英语宝模块检测/
├─ run_report.py           本地测试入口（非交付物，可不上传）
├─ requirements.txt        依赖：pillow、flask
├─ data/
│   └─ inspection_state.json   输入数据（B 产出，C 消费）
├─ screenshots/             APP 原始截图（示例图，演示用）
├─ src/                     你（C）负责的核心代码
│   ├─ trace_engine.py     C1/C2 溯源数据 + 红框标注
│   ├─ error_collector.py  C3 错误输出文件夹
│   ├─ report_exporter.py  C4 HTML/CSV 报告
│   └─ email_sender.py     C5 邮件发送
├─ routes/                  挂在 B 的 web_server 上的 API 蓝图
│   ├─ trace_routes.py     溯源 API（list/detail/screenshot）
│   └─ export_routes.py    导出 API（html/csv/screenshots/email）
└─ outputs/                 (自动生成，已被 .gitignore 忽略)
```

## 你能改 / 不能碰

- ✅ 你能改：`src/trace_engine.py`、`src/error_collector.py`、`src/report_exporter.py`、`src/email_sender.py`、`routes/trace_routes.py`、`routes/export_routes.py`
- ❌ 不要碰（属于 A / B）：`src/review_agent.py`、`src/post_error_check.py`、`src/report_check.py`、`src/script_generator.py`、`src/batch_runner.py`、`src/progress_tracker.py`、`src/recovery_handler.py`、`routes/batch_routes.py`、`web_server.py`

你是**接收方**：读 A/B 产出的 `data/inspection_state.json`，不主动调用他们的函数。

## 本地跑一遍（验证用）

```bash
pip install -r requirements.txt
python run_report.py
```

跑完会在 `outputs/新湘鲁六上/U6_<日期>_<时分>/` 下生成：
`report_errors.html`（仅错误报告，含每题版本/模块/单元/题号与错误详情），以及 `errors/` 错题文件夹（按「版本_单元 / 模块 / 题号」分层，每题含红框图 `marked.png`、原图 `screenshot.png`、`error.json` 与 `error_card.html`）。
注：本地 `run_report.py` 不再生成 `report_full.html` / `summary.csv` / `error_cards.zip` / `错题_*.zip`；如需 CSV 汇总表，请走网页接口（`routes/export_routes.py`）。

`errors/` 按「版本_单元 / 模块 / 题号」分层，例：`errors/新湘鲁六上_U6/模块A/Q03/`，里面含 `screenshot.png` 原图 + `marked.png` 红框图 + `error.json` + `error_card.html`（图+错因合并卡片）。`error_cards.zip` 内部结构与 errors 一致，但只保留 `error_card.html`。

## 接口约定（摘要）

- `TraceEngine.generate(qid, question_data) -> dict`  —— C1 输出
- `ErrorCollector.collect(questions, version, unit) -> dict`  —— C3
- `ReportExporter.export_html_full(questions, metadata) -> str`  —— C4
- `ReportExporter.export_csv(questions) -> str`  —— C4
- `EmailSender.send_report(to_email, subject, html_body="", attachments=None) -> dict`  —— C5

## 提醒

- 红框坐标：`trace_engine.py` 默认用占位区域，真实坐标请让 A/B 把 `error_box` 写进数据（见文件内 `TODO`）。
- 发邮件：QQ/163 邮箱用**授权码**而非登录密码；账号密码放环境变量 `EMAIL_USER` / `EMAIL_PASSWORD`，勿写死上传。
