# -*- coding: utf-8 -*-
"""
routes/export_routes.py — 导出 API (C4 / C5)
============================================
Flask Blueprint 骨架，由 B 同学在 web_server.py 里注册：
    from routes.export_routes import export_bp
    app.register_blueprint(export_bp)
你（C）只写这个文件，不要碰 web_server.py、batch_routes.py。
"""

import os
import json
from datetime import datetime
from flask import Blueprint, jsonify, request, send_file
from src.error_collector import ErrorCollector
from src.report_exporter import ReportExporter
from src.email_sender import EmailSender

export_bp = Blueprint("export", __name__)
DATA_FILE = os.path.join("data", "inspection_state.json")


def _load_questions():
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f).get("questions", {})


@export_bp.route("/api/export/html", methods=["POST"])
def export_html():
    """生成全貌报告 + 仅错误报告，返回文件路径"""
    qs = _load_questions()
    meta = {"version": "新湘鲁六上", "unit": "U6",
            "time": datetime.now().isoformat(timespec="seconds")}
    out = os.path.join("outputs", "export_tmp")
    exp = ReportExporter(out)
    full = exp.export_html_full(qs, meta)
    errs = exp.export_html_errors(qs, meta)
    return jsonify({"report_full": full, "report_errors": errs})


@export_bp.route("/api/export/csv", methods=["POST"])
def export_csv():
    """生成错误汇总 CSV 并下载"""
    qs = _load_questions()
    out = os.path.join("outputs", "export_tmp")
    exp = ReportExporter(out)
    path = exp.export_csv(qs)
    return send_file(path, as_attachment=True)


@export_bp.route("/api/export/screenshots", methods=["POST"])
def export_screenshots():
    """收集错题文件夹（C3）"""
    qs = _load_questions()
    coll = ErrorCollector("outputs")
    res = coll.collect(qs, "新湘鲁六上", 6)
    return jsonify(res)


@export_bp.route("/api/export/email", methods=["POST"])
def export_email():
    """发送报告邮件（C5）"""
    data = request.get_json(silent=True) or {}
    to = data.get("to_email", "")
    subject = data.get("subject", "英语宝检测报告")
    html_body = data.get("html_body", "")
    attachments = data.get("attachments", [])
    sender = EmailSender()
    result = sender.send_report(to, subject, html_body, attachments)
    return jsonify(result)
