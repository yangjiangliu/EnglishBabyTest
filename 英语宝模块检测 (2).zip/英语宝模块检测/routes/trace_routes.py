# -*- coding: utf-8 -*-
"""
routes/trace_routes.py — 溯源 API (C1)
======================================
这是一个 Flask Blueprint 骨架，由 B 同学在 web_server.py 里注册：
    from routes.trace_routes import trace_bp
    app.register_blueprint(trace_bp)
你（C）只写这个文件，不要碰 web_server.py、batch_routes.py。
"""

import os
import json
import tempfile
from flask import Blueprint, jsonify, send_file
from src.trace_engine import TraceEngine

trace_bp = Blueprint("trace", __name__)
DATA_FILE = os.path.join("data", "inspection_state.json")
_engine = TraceEngine()


def _load_questions():
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f).get("questions", {})


@trace_bp.route("/api/trace/list", methods=["GET"])
def list_questions():
    """列出所有题目及其通过/未通过状态"""
    qs = _load_questions()
    return jsonify([
        {"qid": qid, "overall_passed": qd.get("overall_passed")}
        for qid, qd in qs.items()
    ])


@trace_bp.route("/api/trace/detail/<qid>", methods=["GET"])
def detail(qid):
    """返回某题的溯源数据（C1 输出）"""
    qs = _load_questions()
    if qid not in qs:
        return jsonify({"error": "not found"}), 404
    return jsonify(_engine.generate(qid, qs[qid]))


@trace_bp.route("/api/trace/screenshot/<qid>", methods=["GET"])
def screenshot(qid):
    """返回某题的红框标注图（临时生成后返回）"""
    qs = _load_questions()
    if qid not in qs:
        return jsonify({"error": "not found"}), 404
    trace = _engine.generate(qid, qs[qid])
    tmp = os.path.join(tempfile.gettempdir(), f"{qid}_marked.png")
    _engine.draw_mark(qs[qid].get("screenshot", ""), trace["checks"], tmp)
    return send_file(tmp, mimetype="image/png")
