# -*- coding: utf-8 -*-
"""
本地测试入口（C同学用，不是交付物）
==================================
直接跑：python run_report.py
会：① 收集错题 → ② 生成三份报告 → ③ 打印路径
邮件默认关闭，需要时按最底部注释打开。
（真实项目里这一步由 B 的 web_server.py 触发，你不需要提交这个文件到 git）
"""
import os
import sys
import json
import shutil
import glob
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def _load_env_file(path=".env"):
    """读取同目录下的 .env 文件，把 KEY=VALUE 写进 os.environ（仅当该键尚未设置）。

    这样授权码/收件人只需在 .env 里填一次，不用每次在终端敲 set；
    且 .env 已被 .gitignore 忽略，不会随代码上传或分发给别人。
    """
    _p = os.path.join(os.path.dirname(os.path.abspath(__file__)), path)
    if not os.path.exists(_p):
        return
    with open(_p, "r", encoding="utf-8") as f:
        for _line in f:
            _line = _line.strip()
            if not _line or _line.startswith("#") or "=" not in _line:
                continue
            _k, _v = _line.split("=", 1)
            _k, _v = _k.strip(), _v.strip().strip('"').strip("'")
            if _k and _k not in os.environ:
                os.environ[_k] = _v


_load_env_file()  # 在任何读取 EMAIL_* 之前加载


from src.error_collector import ErrorCollector, EYYB_APP_LINK
from src.report_exporter import ReportExporter

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE, "data", "inspection_state.json")

with open(DATA_FILE, "r", encoding="utf-8") as f:
    questions = json.load(f)["questions"]

# 版本/单元从 inspection 数据的 qid 自动读取（qid 格式：教材-模块-单元-题号）
# 这样不用手填，换教材/换单元时 inspection 里是什么就读什么
# —— 支持同批混多个版本：先收集所有未通过题各自的版本/单元，用来生成友好标签
def _norm_unit(seg):
    seg = str(seg)
    return seg if seg.startswith("U") else f"U{seg}"

_ver_set, _unit_set = set(), set()
for _qid, _qd in questions.items():
    if _qd.get("overall_passed") is not False:
        continue
    _p = _qid.split("-")
    if _p:
        _ver_set.add(_p[0])
    if len(_p) >= 3:
        _unit_set.add(_norm_unit(_p[2]))

_first = next(iter(questions))          # 取第一道题的 qid（保留给旧引用）
_parts = _first.split("-")
VERSION = _parts[0]                      # 教材名，如 "新湘鲁六上"
_unit_seg = _parts[2] if len(_parts) >= 3 else "U6"   # 单元段，如 "U6"
UNIT = int(_unit_seg[1:]) if str(_unit_seg).startswith("U") else int(_unit_seg)

def _ver_label():
    vs = sorted(_ver_set)
    return vs[0] if len(vs) == 1 else "多版本(" + "/".join(vs) + ")"

def _unit_label():
    us = sorted(_unit_set)
    return us[0] if len(us) == 1 else "+".join(us)

# 第1步：收集错题（建 errors/ 文件夹 + 红框图）
coll = ErrorCollector(os.path.join(BASE, "outputs"))
res = coll.collect(questions, VERSION, UNIT)
print(f"✅ 收集完成：{res['failed']}/{res['total']} 题出错")
print(f"   输出目录：{res['output_dir']}")

# 第2步：只生成"仅错误报告"report_errors.html（其余产物不再生成）
meta = {"version": _ver_label(), "unit": _unit_label(),
        "time": datetime.now().isoformat(timespec="seconds")}
exp = ReportExporter(res["output_dir"])
p_err = exp.export_html_errors(questions, meta)
print("✅ 报告已生成：")
print(f"   仅错误报告：{p_err}")

# 把 errors/ 打包成一个按"版本/年级/单元/模块/题目"分层的 zip，方便老师解压后直接按层级查看
# zip 内每个题目文件夹包含 marked.png（红框图）+ error_card.html（图+错因合并卡片）
import re
import zipfile

def _split_book(book: str):
    """把 '新湘鲁六上' 拆成 ('新湘鲁', '六上')；找不到年级后缀则整体当版本。"""
    m = re.search(r"([一二三四五六七八九]上|[一二三四五六七八九]下)", book)
    if m:
        return book.replace(m.group(1), ""), m.group(1)
    return book, ""

_errors_dir = os.path.join(res["output_dir"], "errors")
_mail_zip = None
if os.path.isdir(_errors_dir):
    _vu_list = [d for d in os.listdir(_errors_dir)
                if os.path.isdir(os.path.join(_errors_dir, d))]
    if _vu_list:
        if len(_vu_list) == 1:
            _b, _u = _vu_list[0].rsplit("_", 1) if "_" in _vu_list[0] else (_vu_list[0], "U0")
            _bv, _bg = _split_book(_b)
            _zip_name = f"错题_{_bv}_{_bg}_{_u}.zip"
        else:
            _zip_name = "错题_多版本.zip"
        _mail_zip = os.path.join(res["output_dir"], _zip_name)
        with zipfile.ZipFile(_mail_zip, "w", zipfile.ZIP_DEFLATED) as z:
            for _vu in _vu_list:
                _b, _u = _vu.rsplit("_", 1) if "_" in _vu else (_vu, "U0")
                _bv, _bg = _split_book(_b)
                _vu_path = os.path.join(_errors_dir, _vu)
                for _mod in os.listdir(_vu_path):
                    _mod_path = os.path.join(_vu_path, _mod)
                    if not os.path.isdir(_mod_path):
                        continue
                    for _qd in os.listdir(_mod_path):
                        _q_path = os.path.join(_mod_path, _qd)
                        if not os.path.isdir(_q_path):
                            continue
                        for _fn in ("marked.png", "error_card.html"):
                            _full = os.path.join(_q_path, _fn)
                            if os.path.isfile(_full):
                                z.write(_full, os.path.join(_bv, _bg, _u, _mod, _qd, _fn))
        print(f"✅ 错题层级包：{_mail_zip}（结构：版本/年级/单元/模块/题目）")

# 邮件附件：汇总表 + 分层 zip
_attachments = [p_err]
if _mail_zip:
    _attachments.append(_mail_zip)

# 第3步：发邮件（已启用）—— 需先在终端设置好环境变量：EMAIL_USER / EMAIL_PASSWORD / EMAIL_TO
# 账号密码请用邮箱的"授权码"（QQ/163 在邮箱设置里开启 SMTP 服务后获取），不要填登录密码
from src.email_sender import EmailSender
_teacher_email = os.environ.get("EMAIL_TO", "")
if _teacher_email:
    _eyyb_btn = (
        f'<a href="{EYYB_APP_LINK}" target="_blank" rel="noopener" '
        f'style="display:inline-block;padding:9px 16px;background:#1a73e8;'
        f'color:#fff;text-decoration:none;border-radius:6px;font-size:14px;">'
        f'点击进入 e英语宝 查看本题</a>'
    )
    _r = EmailSender().send_report(
        _teacher_email,
        f"英语宝检测汇总 · {_ver_label()} {_unit_label()}",
        html_body=(
            f"<p>老师好，本次英语宝 AI 题目检测的错题汇总见附件：</p>"
            f"<ul>"
            f"<li><b>report_errors.html</b>：全部错题的文字汇总表"
            f"（版本/模块/单元/题号 + 错误维度与原因）。</li>"
            f"<li><b>{os.path.basename(_mail_zip) if _mail_zip else '错题_*.zip'}</b>："
            f"解压后按 版本 / 年级 / 单元 / 模块 / 题目 分层，每个题目文件夹里有 "
            f"<b>marked.png</b>（红框标注图）和 <b>error_card.html</b>（图+错因合并卡片），"
            f"可直接用浏览器打开。</li>"
            f"</ul>"
            f"<p>点下方按钮可在 e英语宝 中查看对应题目：</p>"
            f"<p>{_eyyb_btn}</p>"
        ),
        attachments=_attachments,                   # 错误报告 + 分层错题包
    )
    print(f"📧 邮件发送结果：{_r['message']}")
else:
    print("⚠️ 未设置 EMAIL_TO 环境变量，已跳过发邮件。发送前请先：set EMAIL_TO=老师邮箱")

print("\n🎉 全部完成！")
print(f"   报告目录：{res['output_dir']}")
print(f"   用浏览器打开 report_errors.html 或解压 zip 后的 error_card.html 即可查看。")
